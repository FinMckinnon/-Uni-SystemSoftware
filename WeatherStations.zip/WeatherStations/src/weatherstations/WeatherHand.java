/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weatherstations;

import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;

/**
 *
 * @author User
 */
public class WeatherHand implements Runnable {
    Socket client;
    DataOutputStream out;
    DataInputStream in;
    String data;
    String ID;
    String path;
    private volatile boolean running = true;
    
    public WeatherHand(Socket User, String UserPath) throws IOException{
        client = User;
        path = UserPath;
        out = new DataOutputStream(client.getOutputStream());
        in = new DataInputStream(client.getInputStream());
    }
    
    public void run() {
        try{
            while(running) {
                ID = in.readUTF();
                data = in.readUTF();
                try (BufferedWriter buffWriter = new BufferedWriter(new FileWriter(path))) {
                    buffWriter.write(data);
                    buffWriter.close();
                } catch (IOException e) {
                    
                }
            }
        }
        catch(IOException e){
            
        }
    }
    
    public void stop () {
        running = false;
    }
    
}
