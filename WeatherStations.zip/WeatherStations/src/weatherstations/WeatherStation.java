/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weatherstations;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.InetAddress;
import java.net.Socket;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class WeatherStation implements Runnable{
    
    public void WeatherStation(){
        
    }
    
    private volatile boolean running = true;
    
    public void run(){
        String Type = "weather";
        running = true;
        while(running){
            try{
                InetAddress address = InetAddress.getByName("localhost");
                Socket server = new Socket (address,WeatherStations.returnAddress());
                String InputString ="";
                DataOutputStream output = new DataOutputStream(server.getOutputStream());
                output.writeUTF(Type);

                InputString = JOptionPane.showInputDialog("Weather Station ID to add");
                Reader InputReader = new StringReader(InputString);
                BufferedReader input = new BufferedReader (InputReader);
                String ID = input.readLine();
                output.writeUTF(ID);
                
                double lat = -90.00 + (double)(Math.random()* ((90.00 - -90.00)+1));
                double lon = 0.00 + (double)(Math.random()* ((180.00 - 0.00)+1));
                DecimalFormat df = new DecimalFormat("#.#####");
                String location = (df.format(lat) + ',' + df.format(lon));

                while (running) {
                    output.writeUTF("ID");
                    Random rand = new Random();
                    int temp = rand.nextInt(23) + 12;
                    int windSpeed = rand.nextInt(6) + 2;
                    int rainfall = rand.nextInt(20) + 2;
                    int humidity = rand.nextInt(75) + 20;
                    output.writeUTF(location + "\n" + temp + "\n" + windSpeed + "\n" + rainfall + "\n" + humidity);
                    try{
                        Thread.sleep(7000);
                    } catch (InterruptedException e) {

                    }
                }

            }catch(IOException e) {

            }
        }
    }
    
    public void stop () {
        running = false;
    }
    
}
