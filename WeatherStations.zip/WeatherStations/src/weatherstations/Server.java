/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weatherstations;

import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class Server implements Runnable {
    public void Server(){
        
    }
    
    private volatile boolean running = true;
    
    public void run(){
        final JFrame frame = new JFrame();
        running = true;
        while(running) {
            try {
                ServerSocket server = new ServerSocket(0);
                WeatherStations.currentaddress(server.getLocalPort());
                ArrayList<String> connectedIDs = new ArrayList<>();
                while(running){
                    Socket client = server.accept();
                    DataInputStream in = new DataInputStream(client.getInputStream());
                    String type = in.readUTF();

                    switch (type) {
                        case "weather":
                            String ID = in.readUTF();
                            File dataFile = new File ("Weather_" + ID + ".txt");
                            if (!dataFile.isFile())
                                dataFile.createNewFile();
                            if(!connectedIDs.contains(ID)){
                                JOptionPane.showMessageDialog(frame, "Weather Station " + ID + " has been connected");
                                connectedIDs.add(ID);
                                WeatherStations.updateList(ID);
                                String path = dataFile.getAbsolutePath();
                                WeatherHand handler = new WeatherHand(client,path);
                                Thread t = new Thread((Runnable) handler);
                                t.start();

                                try {
                                    t.sleep(200);
                                } catch (InterruptedException e){

                                }
                            }   break;
                        case "user":
                                UserHand handler = new UserHand(client, connectedIDs);
                                Thread t = new Thread((Runnable) handler);
                                t.start();
                            break;
                    } 
                }
            } catch (IOException ex) {
                Logger.getLogger(WeatherStations.class.getName()).log(Level.SEVERE, null, ex);
                running = false;
            }
        }
    }
    
    public void stop () {
        running = false;
    }
}
