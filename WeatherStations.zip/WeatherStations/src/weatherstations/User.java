/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weatherstations;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.InetAddress;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author User
 */
public class User implements Runnable {
    public void User(){
        
    }
    
    private volatile boolean running = true;
    
    public void run(){
        running = true;
        while(running) {
            try{
                InetAddress address = InetAddress.getByName("localhost");
                Socket server = new Socket(address,WeatherStations.returnAddress());
                DataOutputStream out = new DataOutputStream(server.getOutputStream());
                String Type = "user";
                out.writeUTF(Type);

                DataInputStream inServer = new DataInputStream(server.getInputStream());
                final Pattern lastIntPattern = Pattern.compile("[^0-9]+([0-9]+)$");
                String ID = "";
                while(running){
                    int index = 1;
                    String Message = "";
                    String wantedID = WeatherStations.getList();
                    Matcher matcher = lastIntPattern.matcher(wantedID);
                    if (matcher.find()) {
                        ID = matcher.group(1);
                        out.writeUTF(ID);
                        while(!Message.equals("finish")){
                            Message = inServer.readUTF();
                            if (!Message.equals("finish")){
                                WeatherStations.setConnectedID(Message, index);
                                index += 1;
                            }
                        }
                    }
                    try {
                        Thread.sleep(7000);
                    } catch (InterruptedException ex) {
                    }
                }

            }catch(IOException e){
            }
        }
    }
    
    public void stop () {
        running = false;
    }
}
