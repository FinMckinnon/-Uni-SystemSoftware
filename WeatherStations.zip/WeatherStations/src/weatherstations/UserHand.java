/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weatherstations;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class UserHand implements Runnable {
    Socket client;
    DataOutputStream out;
    DataInputStream in;
    ArrayList<String> IDs;
    private volatile boolean running = true;
    
    public UserHand( Socket User, ArrayList<String> connectedIDs) throws IOException {
        client = User;
        IDs = connectedIDs;
        out = new DataOutputStream(client.getOutputStream());
        in = new DataInputStream(client.getInputStream());
    }
    
    public void run() {
        try{
            String Message = "";
            while (running) {
                Message = in.readUTF();
                out.writeUTF(Message);
                if(IDs.isEmpty()) {
                    out.writeUTF("No Weather Stations Found");
                    out.writeUTF("finish");
                }        
                else {
                    for (int j = 0; j < IDs.size(); j++) {
                        if (IDs.get(j).equals(Message)) {
                            File path = new File("Weather_" + Message + ".txt");
                            BufferedReader buffRead = new BufferedReader(new FileReader(path));
                            String text;
                            while ((text = buffRead.readLine()) != null) {
                                out.writeUTF(text);
                            }
                            out.writeUTF("finish");
                            break;
                        }
                        else if (j == IDs.size() -1) {
                            out.writeUTF("finish");
                            break;
                        }
                    }
                } 
            }
            
        }
        catch(IOException e) {
            
        }
    }
    
    public void stop () {
        running = false;
    }
}
